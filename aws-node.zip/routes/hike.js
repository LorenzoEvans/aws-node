exports.index = (req, res) => {
  res.render('hike', {title: 'My Hiking Log'})
}

exports.add_hike = (req, res) => {
  
}